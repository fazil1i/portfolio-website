<footer class="bg-black text-center py-10" id="contact">
  <h3 class="text-xl font-bold text-cyan-400 mb-2">Contact Us</h3>
  <p class="text-gray-400">Email: <span class="underline">support@cybercrafts.in</span></p>
  <p class="text-sm text-gray-500 mt-4">&copy; <?php echo date('Y'); ?> CyberCrafts. All rights reserved.</p>
  <?php wp_footer(); ?>
</footer>
</body>
</html>
