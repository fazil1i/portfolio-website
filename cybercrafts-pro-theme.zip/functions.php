<?php
function cybercrafts_pro_setup() {
  add_theme_support('title-tag');
  add_theme_support('post-thumbnails');
  register_nav_menus([
    'primary' => __('Primary Menu', 'cybercrafts'),
  ]);
}
add_action('after_setup_theme', 'cybercrafts_pro_setup');

function cybercrafts_pro_enqueue_scripts() {
  wp_enqueue_script('tailwind', 'https://cdn.tailwindcss.com', [], null, false);
}
add_action('wp_enqueue_scripts', 'cybercrafts_pro_enqueue_scripts');
?>
