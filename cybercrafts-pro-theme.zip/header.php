<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <?php wp_head(); ?>
</head>
<body <?php body_class('bg-gray-900 text-white font-sans'); ?>>
<header class="bg-gray-950 p-4 sticky top-0 z-50 shadow">
  <div class="max-w-7xl mx-auto flex items-center justify-between">
    <div class="text-2xl text-cyan-400 font-bold"><?php bloginfo('name'); ?></div>
    <button class="md:hidden" onclick="document.getElementById('nav').classList.toggle('hidden')">☰</button>
    <nav class="hidden md:flex space-x-6 text-white" id="nav">
      <a href="#home" class="hover:text-cyan-300">Home</a>
      <a href="#games" class="hover:text-cyan-300">Games</a>
      <a href="#products" class="hover:text-cyan-300">Products</a>
      <a href="#services" class="hover:text-cyan-300">Services</a>
      <a href="#contact" class="hover:text-cyan-300">Contact</a>
    </nav>
  </div>
</header>
