<?php get_header(); ?>

<section id="home" class="text-center py-20 bg-gradient-to-br from-gray-900 to-black">
  <h1 class="text-4xl font-extrabold text-cyan-300 mb-4">Play Smart. Learn Fast. Shop Digital.</h1>
  <p class="text-gray-400 max-w-xl mx-auto">Your one-stop site for games, products & tech.</p>
  <div class="mt-6 flex justify-center gap-4">
    <a href="#games" class="bg-cyan-500 hover:bg-cyan-600 px-6 py-3 rounded">Play Games</a>
    <a href="#products" class="border border-cyan-500 hover:bg-cyan-700 px-6 py-3 rounded">Shop Now</a>
  </div>
</section>

<section id="games" class="py-16 bg-gray-900">
  <div class="max-w-6xl mx-auto px-4">
    <h2 class="text-3xl font-bold text-center text-cyan-300 mb-8">Games</h2>
    <div class="grid md:grid-cols-3 gap-6">
      <?php
      $games = ["Chess Classic", "Ludo Multiplayer", "Super Mario", "Flappy Bird", "Snake Game", "Tic Tac Toe"];
      foreach ($games as $g) {
        echo "<div class='bg-gray-800 rounded shadow'>
                <img src='https://via.placeholder.com/300x200' alt='{$g}' class='w-full h-40 object-cover rounded-t'>
                <div class='p-4 text-center'>
                  <h4 class='font-semibold text-lg'>{$g}</h4>
                  <a href='game.html?name=" . urlencode($g) . "' target='_blank' class='text-cyan-400 hover:underline'>Play Now</a>
                </div>
              </div>";
      }
      ?>
    </div>
  </div>
</section>

<section id="products" class="py-16 bg-gray-950">
  <div class="max-w-6xl mx-auto px-4">
    <h2 class="text-3xl font-bold text-center text-cyan-300 mb-8">Digital Products</h2>
    <div class="grid md:grid-cols-3 gap-6">
      <?php
      $products = [
        ["Viral Reels Toolkit", "₹199"],
        ["AI Prompt Sheet", "₹149"],
        ["100+ Plugins Pack", "₹299"],
        ["Writerz.ai Access", "₹0"],
        ["Content Writing Course", "₹399"],
        ["Canva Templates", "₹99"]
      ];
      foreach ($products as $p) {
        echo "<div class='bg-gray-800 rounded shadow'>
                <img src='https://via.placeholder.com/300x200' alt='{$p[0]}' class='w-full h-40 object-cover rounded-t'>
                <div class='p-4 text-center'>
                  <h4 class='font-semibold text-lg'>{$p[0]}</h4>
                  <p class='text-gray-400 text-sm'>{$p[1]}</p>
                  <a href='product.html?product=" . urlencode($p[0]) . "' target='_blank' class='block mt-2 px-4 py-2 bg-cyan-500 text-white rounded hover:bg-cyan-600'>Buy Now</a>
                </div>
              </div>";
      }
      ?>
    </div>
  </div>
</section>

<section id="services" class="py-16 bg-gray-900 text-center">
  <h2 class="text-3xl font-bold text-cyan-300 mb-4">🚀 Launch Your Website With Us</h2>
  <p class="text-gray-400 mb-6 max-w-2xl mx-auto">Need a website like this? We build professional, responsive WordPress themes tailored for creators & entrepreneurs.</p>
  <a href="#contact" class="bg-cyan-500 text-white px-6 py-3 rounded hover:bg-cyan-600">Request a Site</a>
</section>

<?php get_footer(); ?>
